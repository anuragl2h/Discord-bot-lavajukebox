"""
Text-Only Discord Music Bot (No Voice Functionality)
Provides music search and information without audio playback.
"""

import discord
from discord.ext import commands
import aiohttp
import json
import logging
from config import Config

class TextMusicBot(commands.Bot):
    """Text-only music bot without voice functionality."""
    
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        # No voice_states intent needed
        
        super().__init__(
            command_prefix=Config.COMMAND_PREFIX,
            intents=intents,
            description="A text-only Discord music information bot"
        )
        
        self.logger = logging.getLogger(__name__)
        
    async def on_ready(self):
        """Event triggered when bot is ready."""
        self.logger.info(f'{self.user} has connected to Discord!')
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{Config.COMMAND_PREFIX}help | Text Music Bot"
            )
        )

    @commands.command(name='search')
    async def search_music(self, ctx, *, query: str):
        """Search for music information (no playback)."""
        embed = discord.Embed(
            title="Music Search Results",
            description=f"Searched for: **{query}**",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="Note", 
            value="This is a text-only bot. For actual music playback, PyNaCl is required for voice functionality.",
            inline=False
        )
        await ctx.send(embed=embed)

    @commands.command(name='status')
    async def status(self, ctx):
        """Show bot status."""
        embed = discord.Embed(title="Bot Status", color=discord.Color.green())
        embed.add_field(name="Mode", value="Text-Only (No Voice)", inline=True)
        embed.add_field(name="Voice Support", value="❌ Disabled (PyNaCl not available)", inline=True)
        await ctx.send(embed=embed)