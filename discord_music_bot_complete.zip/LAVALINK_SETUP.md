# Setting Up Your Own Lavalink Server

For the most reliable music bot experience, we recommend setting up your own Lavalink server instead of relying on public servers.

## Option 1: Railway Deployment (Recommended)

1. **Create Railway Account**: Go to [Railway.app](https://railway.app) and sign up

2. **Deploy Lavalink**: 
   - Click "Deploy Now" 
   - Search for "Lavalink" in templates
   - Choose the official Lavalink template

3. **Configure Environment Variables**:
   ```
   LAVALINK_SERVER_PASSWORD=your_secure_password_here
   LAVALINK_SERVER_PORT=2333
   ```

4. **Get Connection Details**:
   - Host: Your Railway domain (e.g., `yourapp.railway.app`)
   - Port: 443 (HTTPS) or 80 (HTTP)
   - Password: Your secure password

5. **Update Bot Configuration**:
   ```env
   LAVALINK_HOST=yourapp.railway.app
   LAVALINK_PORT=443
   LAVALINK_PASSWORD=your_secure_password_here
   ```

## Option 2: Replit Deployment

1. **Create New Repl**: Choose Java template

2. **Download Lavalink**: Add this to your `run` command:
   ```bash
   wget -O Lavalink.jar https://github.com/lavalink-devs/Lavalink/releases/latest/download/Lavalink.jar
   java -jar Lavalink.jar
   ```

3. **Create application.yml**:
   ```yaml
   server:
     port: 2333
     address: 0.0.0.0
   lavalink:
     server:
       password: "your_password_here"
       sources:
         youtube: true
         soundcloud: true
   ```

## Option 3: VPS/Cloud Server

1. **Server Requirements**:
   - Java 11 or higher
   - 512MB RAM minimum
   - Stable internet connection

2. **Install Java**:
   ```bash
   sudo apt update
   sudo apt install openjdk-17-jdk
   ```

3. **Download and Run Lavalink**:
   ```bash
   wget https://github.com/lavalink-devs/Lavalink/releases/latest/download/Lavalink.jar
   java -jar Lavalink.jar
   ```

## Configuration Files

### application.yml Example
```yaml
server:
  port: 2333
  address: 0.0.0.0

lavalink:
  plugins:
    - dependency: "com.github.topi314.lavasrc:lavasrc-plugin:4.0.1"
      repository: "https://maven.lavalink.dev/releases"
  server:
    password: "your_secure_password"
    sources:
      youtube: true
      bandcamp: true
      soundcloud: true
      twitch: true
      vimeo: true
      nico: true
      http: true
      local: false
    filters:
      volume: true
      equalizer: true
      karaoke: true
      timescale: true
      tremolo: true
      vibrato: true
      distortion: true
      rotation: true
      channelMix: true
      lowPass: true
    bufferDurationMs: 400
    frameBufferDurationMs: 5000
    opusEncodingQuality: 10
    resamplingQuality: LOW
    trackStuckThresholdMs: 10000
    useSeekGhosting: true
    playerUpdateInterval: 5
    youtubePlaylistLoadLimit: 6
    playerUpdateInterval: 5
    youtubeSearchEnabled: true
    soundcloudSearchEnabled: true
    gc-warnings: true

metrics:
  prometheus:
    enabled: false
    endpoint: /metrics

sentry:
  dsn: ""
  environment: ""

logging:
  file:
    path: ./logs/

  level:
    root: INFO
    lavalink: INFO

  request:
    enabled: true
    includeClientInfo: true
    includeHeaders: false
    includeQueryString: true
    includePayload: true
    maxPayloadLength: 10000
```

### Bot Environment Variables
After setting up your server, update these in your bot:

```env
LAVALINK_HOST=your_server_domain_or_ip
LAVALINK_PORT=2333
LAVALINK_PASSWORD=your_secure_password
```

## Security Tips

1. **Use Strong Passwords**: Generate secure passwords for your Lavalink server
2. **Firewall Rules**: Only allow connections from your bot's IP if possible
3. **Regular Updates**: Keep Lavalink updated to the latest version
4. **Monitor Resources**: Check server performance regularly

## Troubleshooting

### Connection Issues
- Verify firewall settings allow port 2333
- Check if Java is running correctly
- Ensure correct password in bot configuration

### Performance Issues
- Monitor RAM usage (increase if needed)
- Check internet bandwidth
- Consider upgrading server specs

### Audio Quality Issues
- Adjust `opusEncodingQuality` in application.yml
- Check server internet connection stability
- Monitor server CPU usage

## Benefits of Own Server

✅ **Reliability**: No dependency on public servers
✅ **Performance**: Dedicated resources for your bot
✅ **Control**: Full control over configuration and updates
✅ **Privacy**: Your music data stays on your server
✅ **Customization**: Add plugins and custom sources