# Discord Music Bot

## Overview

This is a Discord music bot built with Python that integrates with Lavalink for high-quality audio streaming. The bot provides music playback functionality in Discord voice channels, allowing users to play songs from various sources. It uses the discord.py library for Discord API interactions and Lavalink as the audio server backend for reliable music streaming.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Architecture
The system follows a modular architecture with clear separation of concerns:

- **Flask Web Server (`web_app.py`)**: Main entry point running on port 5000 with web interface and API endpoints
- **Main Bot Class (`MusicBot`)**: Extends discord.py's commands.Bot class and handles bot initialization, event management, and cog loading
- **Cog-based Commands**: Music functionality is organized into a separate cog (`MusicCog`) for better code organization and maintainability
- **Configuration Management**: Centralized configuration system using environment variables with fallback defaults
- **Web Interface**: Real-time dashboard for monitoring bot status, managing servers, and viewing logs

### Audio Processing
- **Wavelink Integration**: Uses Wavelink library as a modern wrapper for Lavalink audio servers, providing better error handling and connection management than the old lavalink.py library
- **Node Pool Architecture**: Manages Lavalink nodes through Wavelink's Pool system for better reliability and automatic reconnection
- **Event-driven Audio Handling**: Implements Wavelink event listeners for track lifecycle management (start, end, queue events) with improved error handling

### Voice Channel Management
- **Permission Validation**: Checks for required Discord permissions (CONNECT and SPEAK) before joining voice channels
- **Connection State Management**: Tracks bot connection status and handles automatic connection/disconnection logic
- **Guild-specific Players**: Each Discord server gets its own audio player instance for isolated playback

### Configuration System
- **Environment-based Config**: All settings are configurable via environment variables
- **Fallback Defaults**: Provides sensible defaults for development and testing
- **Runtime Flexibility**: Supports different Lavalink server configurations and bot behavior settings

### Command Structure
- **Prefix-based Commands**: Uses configurable command prefixes for user interaction
- **Permission Checks**: Implements guild-only restrictions for music commands
- **Error Handling**: Includes validation for voice channel presence and bot permissions

### Logging System
- **Multi-level Logging**: Configurable log levels with both file and console output
- **Component-specific Loggers**: Different modules use separate loggers for better debugging
- **Event Tracking**: Logs important events like bot startup, guild connections, and audio events

## External Dependencies

### Core Dependencies
- **Discord.py**: Official Discord API wrapper for Python, handles all Discord interactions and bot functionality
- **Wavelink**: Modern Python client library for Lavalink audio server integration with improved connection management and error handling
- **Python-dotenv**: Environment variable management for configuration loading

### Audio Server
- **Lavalink Server**: External Java-based audio server that handles music streaming, playback, and audio processing (configured via host, port, and authentication)

### Runtime Environment
- **Python 3.7+**: Required runtime environment
- **Discord Bot Token**: Authentication token from Discord Developer Portal
- **Voice Channel Permissions**: Requires CONNECT and SPEAK permissions in Discord servers

### Optional Services
- **Music Sources**: Supports various audio sources through Lavalink (YouTube, SoundCloud, etc.)
- **File Logging**: Local file system for persistent log storage