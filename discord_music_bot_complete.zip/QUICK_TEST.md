# Quick Testing Guide

## Testing Your Discord Music Bot

### 1. Check Bot Status
First, verify the bot is online and connected:
```
!status
```
This shows:
- ✅ Music Server: Connected/Disconnected
- ✅ Voice Connection: Status
- Available Nodes information

### 2. Test Basic Commands
Try these commands in Discord:

**Join a voice channel first**, then:
```
!play never gonna give you up
!pause
!resume
!nowplaying
!queue
!skip
!stop
!disconnect
```

### 3. Expected Behavior

**If Music Server is Connected (✅):**
- `!play` should search and queue songs
- Bot should join your voice channel
- Music should start playing
- All controls should work

**If Music Server is Disconnected (❌):**
- `!play` will show an error message
- Other commands may not work properly
- Try the troubleshooting steps below

### 4. Troubleshooting

**Music Server Down:**
1. Use `!status` to confirm the issue
2. Wait a few minutes (servers restart periodically)
3. Try again - public servers can be unreliable

**Voice Connection Issues:**
1. Make sure you're in a voice channel
2. Check bot has voice permissions
3. Try `!disconnect` then `!play` again

**Bot Not Responding:**
1. Check bot is online in Discord
2. Verify correct command prefix (`!`)
3. Ensure bot has message permissions

### 5. Quick Status Check Commands

- `!status` - Overall bot health
- `!help` - Available commands
- `!ping` - Basic response test (if implemented)

### 6. Success Indicators

✅ **Working properly:**
- Status shows "Music Server: ✅ Connected"
- Bot joins voice channel when you use `!play`
- Music starts playing within 5-10 seconds
- Queue and controls work smoothly

❌ **Needs attention:**
- Status shows "Music Server: ❌ Disconnected"
- Bot doesn't join voice channel
- Error messages when using music commands

### 7. Next Steps

**If everything works:** Your bot is ready! Consider setting up your own Lavalink server for better reliability.

**If music server is down:** This is normal with public servers. Check the LAVALINK_SETUP.md for setting up your own server.

**If other issues:** Check the console logs for error details.