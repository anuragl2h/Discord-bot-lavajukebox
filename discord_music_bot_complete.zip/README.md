# Discord Music Bot (Wavelink Edition)

A Discord music bot built with Python and Wavelink for reliable Lavalink audio streaming.

## Current Status

✅ **Bot Core**: Fully functional Discord bot connected and running
✅ **Commands**: All music commands implemented with Wavelink
✅ **Voice Support**: PyNaCl installed for voice functionality  
✅ **Modern Library**: Upgraded to Wavelink for better reliability
⚠️ **Music Server**: Uses public Lavalink servers (may have occasional downtime)

## Features

- **Music Playback**: Stream music from YouTube and other sources
- **Queue Management**: Add, skip, and manage song queues
- **Voice Controls**: Join, leave, pause, resume functionality
- **Volume Control**: Adjust playback volume
- **Status Monitoring**: Check bot and server status

## Commands

| Command | Aliases | Description |
|---------|---------|-------------|
| `!play <song>` | `!p` | Play a song or add to queue |
| `!pause` | - | Pause current track |
| `!resume` | - | Resume playback |
| `!skip` | `!s` | Skip current track |
| `!stop` | - | Stop and clear queue |
| `!queue` | `!q` | View current queue |
| `!nowplaying` | `!np` | Show current track info |
| `!volume [0-100]` | `!vol` | Set or view volume |
| `!disconnect` | `!dc`, `!leave` | Leave voice channel |
| `!status` | - | Check bot status |

## Setup Instructions

### 1. Discord Bot Setup
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application
3. Go to "Bot" section and create a bot
4. Copy the bot token
5. Add the token to Replit Secrets as `DISCORD_TOKEN`

### 2. Bot Permissions
Your bot needs these permissions in Discord servers:
- Read Messages
- Send Messages
- Connect to voice channels
- Speak in voice channels
- Use Voice Activity

### 3. Lavalink Server (Optional)
For the best experience, you can set up your own Lavalink server:
- Set `LAVALINK_HOST` in environment variables
- Set `LAVALINK_PORT` (default: 2333)
- Set `LAVALINK_PASSWORD` (your server password)

## Environment Variables

Create a `.env` file or set these in Replit Secrets:

```env
DISCORD_TOKEN=your_discord_bot_token
COMMAND_PREFIX=!
LAVALINK_HOST=your_lavalink_server
LAVALINK_PORT=2333
LAVALINK_PASSWORD=your_password
```

## Known Issues

- **Public Lavalink Servers**: Free public music servers are often unreliable
- **Connection Timeouts**: Music servers may go offline periodically
- **Limited Sources**: Some music sources may not be available

## Troubleshooting

### Bot not responding to commands
- Check if bot is online in Discord
- Verify bot has message permissions
- Ensure correct command prefix

### Music commands not working
- Use `!status` to check server connection
- Try waiting a few minutes for server recovery
- Consider setting up your own Lavalink server

### Voice connection issues
- Ensure bot has voice permissions
- Check if you're in a voice channel
- Verify PyNaCl is installed

## Technical Architecture

The bot uses a modular design with Wavelink:
- **Main Bot Class**: Handles Discord connection and Wavelink setup
- **Music Cog**: Contains all music-related commands with enhanced error handling
- **Wavelink Integration**: Modern wrapper for Lavalink audio servers with automatic reconnection
- **Event System**: Comprehensive track and node event handling
- **Configuration System**: Environment-based settings management

## Contributing

The codebase is well-documented and modular. Key files:
- `main.py`: Entry point and logging setup
- `bot.py`: Main bot class and event handlers
- `music_cog.py`: Music commands and functionality
- `lavalink_config.py`: Audio server configuration
- `config.py`: Settings and environment variables

## Support

If you encounter issues:
1. Check the `!status` command for diagnostic information
2. Review the console logs for error details
3. Ensure all environment variables are set correctly
4. Consider using a reliable Lavalink server for production use