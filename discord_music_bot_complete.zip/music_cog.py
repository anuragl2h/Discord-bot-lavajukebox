"""
Discord Music Bot - Music Commands Cog (Wavelink Version)
Contains all music-related commands and functionality using Wavelink.
"""

import discord
from discord.ext import commands
import wavelink
import asyncio
import logging
from config import Config

class MusicCog(commands.Cog):
    """Music commands cog with Wavelink integration."""
    
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        
    def cog_check(self, ctx):
        """Check if command is used in a guild."""
        if not ctx.guild:
            raise commands.NoPrivateMessage('Music commands cannot be used in DMs.')
        return True
    
    @commands.Cog.listener()
    async def on_wavelink_node_ready(self, payload: wavelink.NodeReadyEventPayload) -> None:
        """Event fired when a node has finished connecting."""
        self.logger.info(f"Wavelink node '{payload.node.identifier}' is ready!")
        
    @commands.Cog.listener()
    async def on_wavelink_track_start(self, payload: wavelink.TrackStartEventPayload) -> None:
        """Event fired when a track starts playing."""
        player: wavelink.Player | None = payload.player
        if not player:
            return

        original: wavelink.Playable | None = payload.original
        track: wavelink.Playable = payload.track

        embed = discord.Embed(
            title="Now Playing",
            description=f"**[{track.title}]({track.uri})**",
            color=discord.Color.green()
        )
        embed.add_field(name="Artist", value=track.author, inline=True)
        embed.add_field(name="Duration", value=f"{track.length // 60000}:{(track.length // 1000) % 60:02d}", inline=True)
        
        if track.artwork:
            embed.set_thumbnail(url=track.artwork)
        
        if hasattr(player, 'message_channel') and player.message_channel:
            try:
                await player.message_channel.send(embed=embed)
            except discord.HTTPException:
                pass

    @commands.Cog.listener()
    async def on_wavelink_track_end(self, payload: wavelink.TrackEndEventPayload) -> None:
        """Event fired when a track ends."""
        player: wavelink.Player | None = payload.player
        if not player:
            return
            
        # Auto-disconnect if queue is empty and no one is listening
        if player.queue.is_empty and not player.current:
            await asyncio.sleep(30)  # Wait 30 seconds
            if player.queue.is_empty and not player.current:
                try:
                    await player.disconnect()
                    if hasattr(player, 'message_channel') and player.message_channel:
                        await player.message_channel.send("👋 Disconnected due to inactivity.")
                except:
                    pass

    async def ensure_voice(self, ctx):
        """Ensure bot is connected to a voice channel."""
        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send('❌ You need to be in a voice channel to use music commands!')
            return False
            
        player: wavelink.Player
        player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            try:
                player = await ctx.author.voice.channel.connect(cls=wavelink.Player)
                player.message_channel = ctx.channel
            except discord.ClientException:
                await ctx.send('❌ Could not connect to voice channel!')
                return False
        
        return True

    @commands.command(name='play', aliases=['p'])
    async def play_command(self, ctx, *, search: str = None):
        """Play a song or add it to the queue."""
        if not search:
            await ctx.send(f'❌ Please provide a song name or URL.\nUsage: `{Config.COMMAND_PREFIX}play <song name or URL>`')
            return
            
        if not await self.ensure_voice(ctx):
            return
            
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        # Set message channel for events
        player.message_channel = ctx.channel
        
        try:
            # Search for tracks
            tracks: wavelink.Search = await wavelink.Playable.search(search)
            if not tracks:
                await ctx.send('❌ No tracks found for your search.')
                return
                
            if isinstance(tracks, wavelink.Playlist):
                # Handle playlists
                added = await player.queue.put_wait(tracks)
                embed = discord.Embed(
                    title="Playlist Added!",
                    description=f"Added **{added}** tracks from **{tracks.name}**",
                    color=discord.Color.green()
                )
                await ctx.send(embed=embed)
            else:
                # Handle single track
                track = tracks[0]
                await player.queue.put_wait(track)
                
                embed = discord.Embed(
                    title="Track Added to Queue!",
                    description=f"**[{track.title}]({track.uri})**",
                    color=discord.Color.green()
                )
                embed.add_field(name="Artist", value=track.author, inline=True)
                embed.add_field(name="Duration", value=f"{track.length // 60000}:{(track.length // 1000) % 60:02d}", inline=True)
                embed.add_field(name="Position in Queue", value=player.queue.count, inline=True)
                
                if track.artwork:
                    embed.set_thumbnail(url=track.artwork)
                    
                await ctx.send(embed=embed)
            
            # Start playing if not already playing
            if not player.playing:
                await player.play(player.queue.get())
                
        except wavelink.LavalinkException as e:
            await ctx.send(f'❌ Music server error: {e}')
        except Exception as e:
            self.logger.error(f"Error in play command: {e}")
            await ctx.send('❌ An error occurred while processing your request.')

    @commands.command(name='pause')
    async def pause_command(self, ctx):
        """Pause the current track."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        if player.paused:
            await ctx.send('⏸️ Track is already paused.')
            return
            
        await player.pause(True)
        await ctx.send('⏸️ Track paused.')
        
    @commands.command(name='resume')
    async def resume_command(self, ctx):
        """Resume the current track."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        if not player.paused:
            await ctx.send('▶️ Track is not paused.')
            return
            
        await player.pause(False)
        await ctx.send('▶️ Track resumed.')
        
    @commands.command(name='stop')
    async def stop_command(self, ctx):
        """Stop the current track and clear the queue."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        player.queue.clear()
        await player.stop()
        await ctx.send('⏹️ Playback stopped and queue cleared.')
        
    @commands.command(name='skip', aliases=['s'])
    async def skip_command(self, ctx):
        """Skip the current track."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        if not player.playing:
            await ctx.send('❌ Nothing is currently playing.')
            return
            
        await player.skip(force=True)
        await ctx.send('⏭️ Track skipped.')
        
    @commands.command(name='queue', aliases=['q'])
    async def queue_command(self, ctx, page: int = 1):
        """Display the current queue."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        if player.queue.is_empty:
            await ctx.send('❌ The queue is empty.')
            return
            
        items_per_page = 10
        start = (page - 1) * items_per_page
        end = start + items_per_page
        
        queue_list = list(player.queue)[start:end]
        
        embed = discord.Embed(title=f'Queue - Page {page}', color=discord.Color.blue())
        
        if player.current:
            embed.add_field(
                name='Now Playing',
                value=f'**[{player.current.title}]({player.current.uri})**',
                inline=False
            )
            
        if queue_list:
            queue_text = ''
            for i, track in enumerate(queue_list, start=start+1):
                queue_text += f'{i}. **[{track.title}]({track.uri})**\n'
            embed.add_field(name='Up Next', value=queue_text, inline=False)
            
        embed.set_footer(text=f'Total tracks: {player.queue.count}')
        await ctx.send(embed=embed)
        
    @commands.command(name='nowplaying', aliases=['np'])
    async def now_playing_command(self, ctx):
        """Display information about the current track."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player or not player.current:
            await ctx.send('❌ Nothing is currently playing.')
            return
            
        track = player.current
        embed = discord.Embed(title='Now Playing', color=discord.Color.green())
        embed.description = f'**[{track.title}]({track.uri})**'
        embed.add_field(name='Artist', value=track.author, inline=True)
        embed.add_field(name='Duration', value=f"{track.length // 60000}:{(track.length // 1000) % 60:02d}", inline=True)
        embed.add_field(name='Position', value=f"{player.position // 60000}:{(player.position // 1000) % 60:02d}", inline=True)
        embed.add_field(name='Volume', value=f'{player.volume}%', inline=True)
        
        if player.paused:
            embed.add_field(name='Status', value='⏸️ Paused', inline=True)
        else:
            embed.add_field(name='Status', value='▶️ Playing', inline=True)
            
        if track.artwork:
            embed.set_thumbnail(url=track.artwork)
            
        await ctx.send(embed=embed)
        
    @commands.command(name='volume', aliases=['vol'])
    async def volume_command(self, ctx, volume: int = None):
        """Set or display the current volume."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        if volume is None:
            await ctx.send(f'🔊 Current volume: {player.volume}%')
            return
            
        if not 0 <= volume <= 100:
            await ctx.send('❌ Volume must be between 0 and 100.')
            return
            
        await player.set_volume(volume)
        await ctx.send(f'🔊 Volume set to {volume}%')
        
    @commands.command(name='disconnect', aliases=['dc', 'leave'])
    async def disconnect_command(self, ctx):
        """Disconnect the bot from the voice channel."""
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        
        if not player:
            await ctx.send('❌ Bot is not connected to a voice channel.')
            return
            
        await player.disconnect()
        await ctx.send('👋 Disconnected from voice channel.')
        
    @commands.command(name='status')
    async def status_command(self, ctx):
        """Check bot and music server status."""
        embed = discord.Embed(title='Bot Status', color=discord.Color.blue())
        
        # Check Wavelink connection
        nodes = wavelink.Pool.nodes
        connected_nodes = [node for node in nodes.values() if node.status is wavelink.NodeStatus.CONNECTED]
        
        if connected_nodes:
            embed.add_field(name='Music Server', value='✅ Connected', inline=True)
        else:
            embed.add_field(name='Music Server', value='❌ Disconnected', inline=True)
            
        embed.add_field(name='Available Nodes', value=f'{len(connected_nodes)}/{len(nodes)}', inline=True)
        
        # Check voice connection
        player: wavelink.Player = cast(wavelink.Player, ctx.voice_client)
        if player and player.connected:
            embed.add_field(name='Voice Connection', value='✅ Connected', inline=True)
        else:
            embed.add_field(name='Voice Connection', value='❌ Not connected', inline=True)
            
        # Add troubleshooting info if music server is down
        if not connected_nodes:
            embed.add_field(
                name='Troubleshooting', 
                value='Music features unavailable. This usually means the music server is down. You can:\n• Try again in a few minutes\n• Check if the bot has proper permissions\n• Contact support if issue persists', 
                inline=False
            )
        
        await ctx.send(embed=embed)

def cast(tp, val):
    """Type casting helper for type hints."""
    return val

async def setup(bot):
    """Setup function for loading the cog."""
    await bot.add_cog(MusicCog(bot))